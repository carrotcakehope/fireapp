@echo off
chcp 65001 > nul
title GitHub Upload

cd /d "%~dp0"

echo.
echo ================================
echo  GitHub Auto Upload (supply-fireapp)
echo ================================
echo.

:: Create .gitignore if not exists
if not exist .gitignore (
    echo [INFO] .gitignore 생성 중...
    powershell -NoProfile -Command "$lines = 'node_modules/','*.apk','.claude/'; [System.IO.File]::WriteAllLines('.gitignore', $lines)"
    echo       완료
)

:: Add supply-fireapp remote if not exists
git remote | findstr /X "supply" > nul 2>&1
if %errorlevel% neq 0 (
    echo [INFO] supply-fireapp remote 등록 중...
    git remote add supply https://github.com/carrotcakehope/supply-fireapp.git
    echo       완료
)

:: Show current status
echo [1/3] 변경된 파일 확인 중...
git status --short
echo.

:: Stage all files
echo [2/3] 파일 추가 중...
git add -A
echo       완료

:: Commit with timestamp
echo [3/3] GitHub에 업로드 중...
powershell -NoProfile -Command "git commit -m ('upload: ' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))"
if %errorlevel% neq 0 (
    echo [INFO] 변경된 파일이 없습니다. 업로드 생략.
    pause
    exit /b 0
)

git push supply main
if %errorlevel% neq 0 (
    echo.
    echo [ERROR] Push 실패 - git 로그인 상태를 확인하세요
    pause
    exit /b 1
)

echo.
echo ================================
echo  완료! GitHub에 업로드됐습니다
echo  https://github.com/carrotcakehope/supply-fireapp
echo ================================
echo.
pause
